"""
Ford Triplog

Track your Ford.

Journey data model.

Version: 1.8.6
Release: 1.8.6 - Journey billed-energy price fix
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Final, Literal
from uuid import uuid4
from hashlib import sha256

from .const import GENERATOR, JOURNEY_SCHEMA_VERSION, VERSION

JourneyItemType = Literal["trip", "charge"]

_ITEM_TRIP: Final = "trip"
_ITEM_CHARGE: Final = "charge"
_VALID_ITEM_TYPES: Final = {_ITEM_TRIP, _ITEM_CHARGE}




def build_pause_id(after_item_id: str, before_item_id: str) -> str:
    """Return a stable identifier for a pause between two journey items."""

    value = f"{str(after_item_id).strip()}|{str(before_item_id).strip()}"
    digest = sha256(value.encode("utf-8")).hexdigest()[:16]
    return f"pause_{digest}"


def _as_float(value: Any, default: float = 0.0) -> float:
    """Return a value as float without raising conversion errors."""

    if value is None or isinstance(value, bool):
        return default

    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _as_int(value: Any, default: int = 0) -> int:
    """Return a value as integer without raising conversion errors."""

    if value is None or isinstance(value, bool):
        return default

    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _as_optional_float(value: Any) -> float | None:
    """Return an optional float value."""

    if value is None or isinstance(value, bool):
        return None

    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _as_optional_string(value: Any) -> str | None:
    """Return an optional non-empty string."""

    if value is None:
        return None

    result = str(value).strip()
    return result or None


def _normalize_iso_datetime(value: Any) -> str | None:
    """Return an ISO datetime string when the value is usable."""

    if isinstance(value, datetime):
        return value.isoformat()

    return _as_optional_string(value)


def _date_from_datetime(value: str | None) -> str | None:
    """Return the ISO date part of an ISO datetime string."""

    if not value:
        return None

    try:
        return datetime.fromisoformat(value).date().isoformat()
    except ValueError:
        return value[:10] if len(value) >= 10 else None


@dataclass(slots=True)
class JourneyItem:
    """Reference to one trip or charging session inside a journey."""

    item_type: JourneyItemType
    item_id: str
    start_time: str | None = None
    end_time: str | None = None

    distance_km: float | None = None
    duration_seconds: int | None = None
    energy_kwh: float | None = None
    start_soc: float | None = None
    end_soc: float | None = None

    start_location: str | None = None
    start_address: str | None = None
    start_latitude: float | None = None
    start_longitude: float | None = None
    start_location_source: str | None = None

    end_location: str | None = None
    end_address: str | None = None
    end_latitude: float | None = None
    end_longitude: float | None = None
    end_location_source: str | None = None

    location: str | None = None
    address: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    location_source: str | None = None

    energy_billed_kwh: float | None = None
    cost_total: float | None = None
    energy_cost: float | None = None
    energy_price_per_kwh: float | None = None
    effective_price_per_kwh: float | None = None
    currency: str | None = None
    cost_source: str | None = None

    def __post_init__(self) -> None:
        """Validate and normalize the journey item."""

        if self.item_type not in _VALID_ITEM_TYPES:
            raise ValueError(
                f"Unsupported journey item type: {self.item_type}"
            )

        self.item_id = str(self.item_id).strip()
        if not self.item_id:
            raise ValueError("Journey item ID must not be empty")

        self.start_time = _normalize_iso_datetime(self.start_time)
        self.end_time = _normalize_iso_datetime(self.end_time)

        self.distance_km = _as_optional_float(self.distance_km)
        self.duration_seconds = (
            None
            if self.duration_seconds is None
            else max(0, _as_int(self.duration_seconds))
        )
        self.energy_kwh = _as_optional_float(self.energy_kwh)
        self.start_soc = _as_optional_float(self.start_soc)
        self.end_soc = _as_optional_float(self.end_soc)

        for field_name in (
            "start_location",
            "start_address",
            "start_location_source",
            "end_location",
            "end_address",
            "end_location_source",
            "location",
            "address",
            "location_source",
        ):
            setattr(
                self,
                field_name,
                _as_optional_string(getattr(self, field_name)),
            )

        self.start_latitude = _as_optional_float(self.start_latitude)
        self.start_longitude = _as_optional_float(self.start_longitude)
        self.end_latitude = _as_optional_float(self.end_latitude)
        self.end_longitude = _as_optional_float(self.end_longitude)
        self.latitude = _as_optional_float(self.latitude)
        self.longitude = _as_optional_float(self.longitude)

        self.energy_billed_kwh = _as_optional_float(
            self.energy_billed_kwh
        )
        self.cost_total = _as_optional_float(self.cost_total)
        self.energy_cost = _as_optional_float(self.energy_cost)
        self.energy_price_per_kwh = _as_optional_float(
            self.energy_price_per_kwh
        )
        self.effective_price_per_kwh = _as_optional_float(
            self.effective_price_per_kwh
        )
        self.currency = _as_optional_string(self.currency)
        self.cost_source = _as_optional_string(self.cost_source)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the journey item."""

        data = {
            "type": self.item_type,
            "id": self.item_id,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "distance_km": self.distance_km,
            "duration_seconds": self.duration_seconds,
            "energy_kwh": self.energy_kwh,
            "start_soc": self.start_soc,
            "end_soc": self.end_soc,
            "start_location": self.start_location,
            "start_address": self.start_address,
            "start_latitude": self.start_latitude,
            "start_longitude": self.start_longitude,
            "start_location_source": self.start_location_source,
            "end_location": self.end_location,
            "end_address": self.end_address,
            "end_latitude": self.end_latitude,
            "end_longitude": self.end_longitude,
            "end_location_source": self.end_location_source,
            "location": self.location,
            "address": self.address,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "location_source": self.location_source,
            "energy_billed_kwh": self.energy_billed_kwh,
            "cost_total": self.cost_total,
            "energy_cost": self.energy_cost,
            "energy_price_per_kwh": self.energy_price_per_kwh,
            "effective_price_per_kwh": self.effective_price_per_kwh,
            "currency": self.currency,
            "cost_source": self.cost_source,
        }

        return {
            key: value
            for key, value in data.items()
            if value is not None
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> JourneyItem:
        """Create a journey item from stored data."""

        return cls(
            item_type=str(data.get("type", "")).strip(),
            item_id=str(data.get("id", "")).strip(),
            start_time=data.get("start_time"),
            end_time=data.get("end_time"),
            distance_km=data.get("distance_km"),
            duration_seconds=data.get("duration_seconds"),
            energy_kwh=data.get("energy_kwh"),
            start_soc=data.get("start_soc"),
            end_soc=data.get("end_soc"),
            start_location=data.get("start_location"),
            start_address=data.get("start_address"),
            start_latitude=data.get("start_latitude"),
            start_longitude=data.get("start_longitude"),
            start_location_source=data.get("start_location_source"),
            end_location=data.get("end_location"),
            end_address=data.get("end_address"),
            end_latitude=data.get("end_latitude"),
            end_longitude=data.get("end_longitude"),
            end_location_source=data.get("end_location_source"),
            location=data.get("location"),
            address=data.get("address"),
            latitude=data.get("latitude"),
            longitude=data.get("longitude"),
            location_source=data.get("location_source"),
            energy_billed_kwh=data.get("energy_billed_kwh"),
            cost_total=data.get("cost_total"),
            energy_cost=data.get("energy_cost"),
            energy_price_per_kwh=data.get(
                "energy_price_per_kwh"
            ),
            effective_price_per_kwh=data.get(
                "effective_price_per_kwh"
            ),
            currency=data.get("currency"),
            cost_source=data.get("cost_source"),
        )


@dataclass(slots=True)
class FordTriplogJourney:
    """Represent one daily journey containing trips and charges."""

    journey_id: str = field(
        default_factory=lambda: f"journey_{uuid4().hex}"
    )
    created: str = field(
        default_factory=lambda: datetime.now().astimezone().isoformat()
    )
    date: str | None = None

    start_time: str | None = None
    end_time: str | None = None

    start_address: str | None = None
    end_address: str | None = None

    start_latitude: float | None = None
    start_longitude: float | None = None
    end_latitude: float | None = None
    end_longitude: float | None = None

    trip_ids: list[str] = field(default_factory=list)
    charge_ids: list[str] = field(default_factory=list)
    items: list[JourneyItem] = field(default_factory=list)
    pause_overrides: dict[str, dict[str, Any]] = field(default_factory=dict)

    trip_count: int = 0
    charge_count: int = 0

    distance_km: float = 0.0
    driving_duration_seconds: int = 0
    charging_duration_seconds: int = 0
    total_duration_seconds: int = 0

    energy_used_kwh: float = 0.0
    energy_charged_kwh: float = 0.0
    average_consumption_kwh_100km: float = 0.0

    charging_cost_total: float = 0.0
    charging_energy_cost: float = 0.0
    charging_additional_cost: float = 0.0
    average_charging_price_per_kwh: float = 0.0
    currency: str | None = None

    start_soc: float | None = None
    end_soc: float | None = None
    soc_delta: float = 0.0
    soc_used: float = 0.0
    soc_charged: float = 0.0
    soc_adjustment: float = 0.0

    battery_capacity_kwh: float | None = None
    battery_energy_delta_kwh: float | None = None
    soc_adjustment_kwh: float | None = None
    battery_energy_balance_kwh: float = 0.0
    total_energy_flow_kwh: float = 0.0

    schema: int = JOURNEY_SCHEMA_VERSION
    generator: str = GENERATOR
    version: str = VERSION

    def __post_init__(self) -> None:
        """Normalize values and rebuild derived fields."""

        self.journey_id = str(self.journey_id).strip()
        if not self.journey_id:
            raise ValueError("Journey ID must not be empty")

        self.created = (
            _normalize_iso_datetime(self.created)
            or datetime.now().astimezone().isoformat()
        )
        self.start_time = _normalize_iso_datetime(self.start_time)
        self.end_time = _normalize_iso_datetime(self.end_time)

        self.start_address = _as_optional_string(self.start_address)
        self.end_address = _as_optional_string(self.end_address)

        self.start_latitude = _as_optional_float(self.start_latitude)
        self.start_longitude = _as_optional_float(self.start_longitude)
        self.end_latitude = _as_optional_float(self.end_latitude)
        self.end_longitude = _as_optional_float(self.end_longitude)

        self.distance_km = max(0.0, _as_float(self.distance_km))
        self.driving_duration_seconds = max(
            0,
            _as_int(self.driving_duration_seconds),
        )
        self.charging_duration_seconds = max(
            0,
            _as_int(self.charging_duration_seconds),
        )
        self.energy_used_kwh = max(
            0.0,
            _as_float(self.energy_used_kwh),
        )
        self.energy_charged_kwh = max(
            0.0,
            _as_float(self.energy_charged_kwh),
        )
        self.charging_cost_total = max(
            0.0,
            _as_float(self.charging_cost_total),
        )
        self.charging_energy_cost = max(
            0.0,
            _as_float(self.charging_energy_cost),
        )
        self.charging_additional_cost = max(
            0.0,
            _as_float(self.charging_additional_cost),
        )
        self.average_charging_price_per_kwh = max(
            0.0,
            _as_float(self.average_charging_price_per_kwh),
        )
        self.currency = _as_optional_string(self.currency)
        self.start_soc = _as_optional_float(self.start_soc)
        self.end_soc = _as_optional_float(self.end_soc)
        self.soc_delta = _as_float(self.soc_delta)
        self.soc_used = max(0.0, _as_float(self.soc_used))
        self.soc_charged = max(0.0, _as_float(self.soc_charged))
        self.soc_adjustment = _as_float(self.soc_adjustment)
        self.battery_capacity_kwh = _as_optional_float(
            self.battery_capacity_kwh
        )
        if (
            self.battery_capacity_kwh is not None
            and self.battery_capacity_kwh <= 0
        ):
            self.battery_capacity_kwh = None

        self.battery_energy_delta_kwh = _as_optional_float(
            self.battery_energy_delta_kwh
        )
        self.soc_adjustment_kwh = _as_optional_float(
            self.soc_adjustment_kwh
        )
        self.battery_energy_balance_kwh = _as_float(
            self.battery_energy_balance_kwh
        )
        self.total_energy_flow_kwh = max(
            0.0,
            _as_float(self.total_energy_flow_kwh),
        )

        normalized_items: list[JourneyItem] = []
        for item in self.items:
            if isinstance(item, JourneyItem):
                normalized_items.append(item)
            elif isinstance(item, dict):
                normalized_items.append(JourneyItem.from_dict(item))
            else:
                raise TypeError(
                    "Journey items must be JourneyItem objects or dictionaries"
                )

        self.items = normalized_items
        normalized_pause_overrides: dict[str, dict[str, Any]] = {}
        if isinstance(self.pause_overrides, dict):
            for pause_id, override in self.pause_overrides.items():
                normalized_id = str(pause_id).strip()
                if normalized_id and isinstance(override, dict):
                    normalized_pause_overrides[normalized_id] = dict(override)
        self.pause_overrides = normalized_pause_overrides
        self._rebuild_references()
        self.recalculate()

        if self.date is None:
            self.date = _date_from_datetime(self.start_time)

    def add_trip(
        self,
        trip_id: str,
        *,
        start_time: str | datetime | None = None,
        end_time: str | datetime | None = None,
        distance_km: float = 0.0,
        duration_seconds: int = 0,
        energy_used_kwh: float = 0.0,
        start_soc: float | None = None,
        end_soc: float | None = None,
        start_location: str | None = None,
        start_address: str | None = None,
        start_latitude: float | None = None,
        start_longitude: float | None = None,
        start_location_source: str | None = None,
        end_location: str | None = None,
        end_address: str | None = None,
        end_latitude: float | None = None,
        end_longitude: float | None = None,
        end_location_source: str | None = None,
    ) -> bool:
        """Add a trip reference and its aggregate values.

        Return False when the trip is already part of this journey.
        """

        normalized_id = str(trip_id).strip()
        if not normalized_id:
            raise ValueError("Trip ID must not be empty")

        if normalized_id in self.trip_ids:
            return False

        item = JourneyItem(
            item_type=_ITEM_TRIP,
            item_id=normalized_id,
            start_time=start_time,
            end_time=end_time,
            distance_km=max(0.0, _as_float(distance_km)),
            duration_seconds=max(0, _as_int(duration_seconds)),
            energy_kwh=max(0.0, _as_float(energy_used_kwh)),
            start_soc=start_soc,
            end_soc=end_soc,
            start_location=start_location,
            start_address=start_address,
            start_latitude=start_latitude,
            start_longitude=start_longitude,
            start_location_source=start_location_source,
            end_location=end_location,
            end_address=end_address,
            end_latitude=end_latitude,
            end_longitude=end_longitude,
            end_location_source=end_location_source,
        )
        self.items.append(item)

        self.distance_km += max(0.0, _as_float(distance_km))
        self.driving_duration_seconds += max(
            0,
            _as_int(duration_seconds),
        )
        self.energy_used_kwh += max(
            0.0,
            _as_float(energy_used_kwh),
        )

        self._apply_boundary_data(
            item=item,
            start_address=start_address,
            end_address=end_address,
            start_latitude=start_latitude,
            start_longitude=start_longitude,
            end_latitude=end_latitude,
            end_longitude=end_longitude,
        )
        self._rebuild_references()
        self.recalculate()
        return True

    def add_charge(
        self,
        charge_id: str,
        *,
        start_time: str | datetime | None = None,
        end_time: str | datetime | None = None,
        duration_seconds: int = 0,
        energy_charged_kwh: float = 0.0,
        start_soc: float | None = None,
        end_soc: float | None = None,
        location: str | None = None,
        address: str | None = None,
        latitude: float | None = None,
        longitude: float | None = None,
        location_source: str | None = None,
        energy_billed_kwh: float | None = None,
        cost_total: float | None = None,
        energy_cost: float | None = None,
        energy_price_per_kwh: float | None = None,
        effective_price_per_kwh: float | None = None,
        currency: str | None = None,
        cost_source: str | None = None,
    ) -> bool:
        """Add a charging-session reference and its aggregate values.

        Return False when the charge is already part of this journey.
        """

        normalized_id = str(charge_id).strip()
        if not normalized_id:
            raise ValueError("Charge ID must not be empty")

        if normalized_id in self.charge_ids:
            return False

        self.items.append(
            JourneyItem(
                item_type=_ITEM_CHARGE,
                item_id=normalized_id,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=max(0, _as_int(duration_seconds)),
                energy_kwh=max(0.0, _as_float(energy_charged_kwh)),
                start_soc=start_soc,
                end_soc=end_soc,
                location=location,
                address=address,
                latitude=latitude,
                longitude=longitude,
                location_source=location_source,
                energy_billed_kwh=energy_billed_kwh,
                cost_total=cost_total,
                energy_cost=energy_cost,
                energy_price_per_kwh=energy_price_per_kwh,
                effective_price_per_kwh=effective_price_per_kwh,
                currency=currency,
                cost_source=cost_source,
            )
        )

        self.charging_duration_seconds += max(
            0,
            _as_int(duration_seconds),
        )
        self.energy_charged_kwh += max(
            0.0,
            _as_float(energy_charged_kwh),
        )

        self._rebuild_references()
        self.recalculate()
        return True

    def recalculate(self) -> None:
        """Recalculate all values derived from current journey data."""

        self.trip_count = len(self.trip_ids)
        self.charge_count = len(self.charge_ids)

        if self.items:
            first_item = self.items[0]
            last_item = self.items[-1]

            if first_item.start_time:
                self.start_time = first_item.start_time
            if last_item.end_time:
                self.end_time = last_item.end_time

        self.date = self.date or _date_from_datetime(self.start_time)

        self._recalculate_soc_values()
        self._recalculate_charging_costs()
        self._recalculate_energy_balance()
        self._recalculate_capacity_energy_values()
        self.total_duration_seconds = self._calculate_total_duration()

        if self.distance_km > 0:
            self.average_consumption_kwh_100km = round(
                self.energy_used_kwh / self.distance_km * 100,
                2,
            )
        else:
            self.average_consumption_kwh_100km = 0.0

        self.distance_km = round(self.distance_km, 3)
        self.energy_used_kwh = round(self.energy_used_kwh, 3)
        self.energy_charged_kwh = round(self.energy_charged_kwh, 3)
        self.charging_cost_total = round(self.charging_cost_total, 2)
        self.charging_energy_cost = round(self.charging_energy_cost, 2)
        self.charging_additional_cost = round(
            self.charging_additional_cost,
            2,
        )
        self.average_charging_price_per_kwh = round(
            self.average_charging_price_per_kwh,
            4,
        )
        self.soc_delta = round(self.soc_delta, 3)
        self.soc_used = round(self.soc_used, 3)
        self.soc_charged = round(self.soc_charged, 3)
        self.soc_adjustment = round(self.soc_adjustment, 3)
        self.battery_energy_balance_kwh = round(
            self.battery_energy_balance_kwh,
            3,
        )
        self.total_energy_flow_kwh = round(
            self.total_energy_flow_kwh,
            3,
        )
        if self.battery_capacity_kwh is not None:
            self.battery_capacity_kwh = round(
                self.battery_capacity_kwh,
                3,
            )
        if self.battery_energy_delta_kwh is not None:
            self.battery_energy_delta_kwh = round(
                self.battery_energy_delta_kwh,
                3,
            )
        if self.soc_adjustment_kwh is not None:
            self.soc_adjustment_kwh = round(
                self.soc_adjustment_kwh,
                3,
            )

    def is_same_day(self) -> bool:
        """Return whether the journey starts and ends on the same date."""

        start_date = _date_from_datetime(self.start_time)
        end_date = _date_from_datetime(self.end_time)

        if start_date is None or end_date is None:
            return True

        return start_date == end_date

    def to_dict(self) -> dict[str, Any]:
        """Serialize the complete journey."""

        self._rebuild_references()
        self.recalculate()

        return {
            "schema": self.schema,
            "journey_id": self.journey_id,
            "created": self.created,
            "date": self.date,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "start_address": self.start_address,
            "end_address": self.end_address,
            "start_latitude": self.start_latitude,
            "start_longitude": self.start_longitude,
            "end_latitude": self.end_latitude,
            "end_longitude": self.end_longitude,
            "trip_ids": list(self.trip_ids),
            "charge_ids": list(self.charge_ids),
            "items": [item.to_dict() for item in self.items],
            "pause_overrides": dict(self.pause_overrides),
            "trip_count": self.trip_count,
            "charge_count": self.charge_count,
            "distance_km": self.distance_km,
            "driving_duration_seconds": self.driving_duration_seconds,
            "charging_duration_seconds": self.charging_duration_seconds,
            "total_duration_seconds": self.total_duration_seconds,
            "energy_used_kwh": self.energy_used_kwh,
            "energy_charged_kwh": self.energy_charged_kwh,
            "average_consumption_kwh_100km": (
                self.average_consumption_kwh_100km
            ),
            "charging_cost_total": self.charging_cost_total,
            "charging_energy_cost": self.charging_energy_cost,
            "charging_additional_cost": self.charging_additional_cost,
            "average_charging_price_per_kwh": (
                self.average_charging_price_per_kwh
            ),
            "currency": self.currency,
            "start_soc": self.start_soc,
            "end_soc": self.end_soc,
            "soc_delta": self.soc_delta,
            "soc_used": self.soc_used,
            "soc_charged": self.soc_charged,
            "soc_adjustment": self.soc_adjustment,
            "battery_capacity_kwh": self.battery_capacity_kwh,
            "battery_energy_delta_kwh": (
                self.battery_energy_delta_kwh
            ),
            "soc_adjustment_kwh": self.soc_adjustment_kwh,
            "battery_energy_balance_kwh": (
                self.battery_energy_balance_kwh
            ),
            "total_energy_flow_kwh": self.total_energy_flow_kwh,
            "generator": self.generator,
            "version": self.version,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FordTriplogJourney:
        """Create a journey from stored data."""

        if not isinstance(data, dict):
            raise TypeError("Journey data must be a dictionary")

        raw_items = data.get("items", [])
        items = raw_items if isinstance(raw_items, list) else []

        return cls(
            schema=_as_int(
                data.get("schema"),
                JOURNEY_SCHEMA_VERSION,
            ),
            journey_id=str(data.get("journey_id", "")).strip(),
            created=data.get("created"),
            date=_as_optional_string(data.get("date")),
            start_time=data.get("start_time"),
            end_time=data.get("end_time"),
            start_address=data.get("start_address"),
            end_address=data.get("end_address"),
            start_latitude=data.get("start_latitude"),
            start_longitude=data.get("start_longitude"),
            end_latitude=data.get("end_latitude"),
            end_longitude=data.get("end_longitude"),
            trip_ids=list(data.get("trip_ids", [])),
            charge_ids=list(data.get("charge_ids", [])),
            items=items,
            pause_overrides=(
                dict(data.get("pause_overrides", {}))
                if isinstance(data.get("pause_overrides"), dict)
                else {}
            ),
            trip_count=_as_int(data.get("trip_count")),
            charge_count=_as_int(data.get("charge_count")),
            distance_km=_as_float(data.get("distance_km")),
            driving_duration_seconds=_as_int(
                data.get("driving_duration_seconds")
            ),
            charging_duration_seconds=_as_int(
                data.get("charging_duration_seconds")
            ),
            total_duration_seconds=_as_int(
                data.get("total_duration_seconds")
            ),
            energy_used_kwh=_as_float(data.get("energy_used_kwh")),
            energy_charged_kwh=_as_float(
                data.get("energy_charged_kwh")
            ),
            average_consumption_kwh_100km=_as_float(
                data.get("average_consumption_kwh_100km")
            ),
            charging_cost_total=_as_float(
                data.get("charging_cost_total")
            ),
            charging_energy_cost=_as_float(
                data.get("charging_energy_cost")
            ),
            charging_additional_cost=_as_float(
                data.get("charging_additional_cost")
            ),
            average_charging_price_per_kwh=_as_float(
                data.get("average_charging_price_per_kwh")
            ),
            currency=_as_optional_string(data.get("currency")),
            start_soc=_as_optional_float(data.get("start_soc")),
            end_soc=_as_optional_float(data.get("end_soc")),
            soc_delta=_as_float(data.get("soc_delta")),
            soc_used=_as_float(data.get("soc_used")),
            soc_charged=_as_float(data.get("soc_charged")),
            soc_adjustment=_as_float(data.get("soc_adjustment")),
            battery_capacity_kwh=_as_optional_float(
                data.get("battery_capacity_kwh")
            ),
            battery_energy_delta_kwh=_as_optional_float(
                data.get("battery_energy_delta_kwh")
            ),
            soc_adjustment_kwh=_as_optional_float(
                data.get("soc_adjustment_kwh")
            ),
            battery_energy_balance_kwh=_as_float(
                data.get("battery_energy_balance_kwh")
            ),
            total_energy_flow_kwh=_as_float(
                data.get("total_energy_flow_kwh")
            ),
            generator=str(data.get("generator", GENERATOR)),
            version=str(data.get("version", VERSION)),
        )

    def _rebuild_references(self) -> None:
        """Rebuild ordered, duplicate-free trip and charge references."""

        trip_ids: list[str] = []
        charge_ids: list[str] = []
        seen: set[tuple[str, str]] = set()
        unique_items: list[JourneyItem] = []

        for item in self.items:
            key = (item.item_type, item.item_id)
            if key in seen:
                continue

            seen.add(key)
            unique_items.append(item)

            if item.item_type == _ITEM_TRIP:
                trip_ids.append(item.item_id)
            elif item.item_type == _ITEM_CHARGE:
                charge_ids.append(item.item_id)

        self.items = unique_items
        self.trip_ids = trip_ids
        self.charge_ids = charge_ids

    def _apply_boundary_data(
        self,
        *,
        item: JourneyItem,
        start_address: str | None,
        end_address: str | None,
        start_latitude: float | None,
        start_longitude: float | None,
        end_latitude: float | None,
        end_longitude: float | None,
    ) -> None:
        """Update journey start and end information from a trip."""

        if self.trip_count == 0:
            self.start_address = _as_optional_string(start_address)
            self.start_latitude = _as_optional_float(start_latitude)
            self.start_longitude = _as_optional_float(start_longitude)

            if item.start_time:
                self.start_time = item.start_time

        normalized_end_address = _as_optional_string(end_address)
        if normalized_end_address is not None:
            self.end_address = normalized_end_address

        normalized_end_latitude = _as_optional_float(end_latitude)
        if normalized_end_latitude is not None:
            self.end_latitude = normalized_end_latitude

        normalized_end_longitude = _as_optional_float(end_longitude)
        if normalized_end_longitude is not None:
            self.end_longitude = normalized_end_longitude

        if item.end_time:
            self.end_time = item.end_time

    def _recalculate_soc_values(self) -> None:
        """Recalculate journey-wide SOC values from ordered items."""

        first_soc: float | None = None
        last_soc: float | None = None
        previous_end_soc: float | None = None
        soc_used = 0.0
        soc_charged = 0.0
        soc_adjustment = 0.0

        for item in self.items:
            if first_soc is None:
                if item.start_soc is not None:
                    first_soc = item.start_soc
                elif item.end_soc is not None:
                    first_soc = item.end_soc

            if (
                previous_end_soc is not None
                and item.start_soc is not None
            ):
                soc_adjustment += item.start_soc - previous_end_soc

            if item.end_soc is not None:
                last_soc = item.end_soc
                previous_end_soc = item.end_soc
            elif item.start_soc is not None:
                last_soc = item.start_soc
                previous_end_soc = item.start_soc

            if item.start_soc is None or item.end_soc is None:
                continue

            soc_change = item.end_soc - item.start_soc

            if item.item_type == _ITEM_TRIP and soc_change < 0:
                soc_used += abs(soc_change)
            elif item.item_type == _ITEM_CHARGE and soc_change > 0:
                soc_charged += soc_change

        self.start_soc = first_soc
        self.end_soc = last_soc
        self.soc_used = soc_used
        self.soc_charged = soc_charged
        self.soc_adjustment = soc_adjustment

        if first_soc is not None and last_soc is not None:
            self.soc_delta = last_soc - first_soc
        else:
            self.soc_delta = 0.0

    def _recalculate_charging_costs(self) -> None:
        """Recalculate journey-wide charging cost values."""

        total_cost = 0.0
        energy_cost = 0.0
        pricing_energy_kwh = 0.0
        currencies: set[str] = set()

        for item in self.items:
            if item.item_type != _ITEM_CHARGE:
                continue

            if item.cost_total is not None:
                total_cost += max(0.0, item.cost_total)

            if item.energy_cost is not None:
                energy_cost += max(0.0, item.energy_cost)

            if (
                item.energy_billed_kwh is not None
                and item.energy_billed_kwh > 0
            ):
                pricing_energy_kwh += item.energy_billed_kwh
            elif item.energy_kwh is not None and item.energy_kwh > 0:
                # Backward-compatible fallback when no billed energy exists.
                pricing_energy_kwh += item.energy_kwh

            if item.currency:
                currencies.add(item.currency.upper())

        self.charging_cost_total = total_cost
        self.charging_energy_cost = energy_cost
        self.charging_additional_cost = max(
            0.0,
            total_cost - energy_cost,
        )

        if pricing_energy_kwh > 0:
            self.average_charging_price_per_kwh = (
                total_cost / pricing_energy_kwh
            )
        else:
            self.average_charging_price_per_kwh = 0.0

        self.currency = (
            next(iter(currencies))
            if len(currencies) == 1
            else None
        )

    def _recalculate_energy_balance(self) -> None:
        """Recalculate journey-wide energy flow values."""

        self.battery_energy_balance_kwh = (
            self.energy_charged_kwh - self.energy_used_kwh
        )
        self.total_energy_flow_kwh = (
            self.energy_charged_kwh + self.energy_used_kwh
        )

    def _recalculate_capacity_energy_values(self) -> None:
        """Convert SOC changes using the stored usable battery capacity."""

        if self.battery_capacity_kwh is None:
            self.battery_energy_delta_kwh = None
            self.soc_adjustment_kwh = None
            return

        self.battery_energy_delta_kwh = (
            self.soc_delta * self.battery_capacity_kwh / 100
        )
        self.soc_adjustment_kwh = (
            self.soc_adjustment * self.battery_capacity_kwh / 100
        )

    def _calculate_total_duration(self) -> int:
        """Calculate elapsed journey duration from start to end."""

        if self.start_time and self.end_time:
            try:
                start = datetime.fromisoformat(self.start_time)
                end = datetime.fromisoformat(self.end_time)
                return max(0, int((end - start).total_seconds()))
            except (TypeError, ValueError):
                pass

        return (
            self.driving_duration_seconds
            + self.charging_duration_seconds
        )
